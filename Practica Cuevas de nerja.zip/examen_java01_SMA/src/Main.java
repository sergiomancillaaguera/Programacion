import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);

       System.out.print("Nombre de cliente: ");
       //ticket.getentradasAdultos = scan.nextInt();
        
        
        
        Ticket ticket = new Ticket(5, 2, 3, "Sandra");

        System.out.println(ticket.getentradasAdultos());


    }
    
    
    
}
