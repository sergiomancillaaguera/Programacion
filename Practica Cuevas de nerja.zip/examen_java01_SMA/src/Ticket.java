

public class Ticket {
    private int entradasAdultos;
    private int entradasNinhos;
    private int audioguias;
    private String cliente;


    public static double precioAdultos = 9.6;
    public static double precioNinhos = 4.95;
    public static double precioAudioguias = 3.5;
    public static double descuentoguias = precioAudioguias * 0.17;
    public static double audioguiasConDescuento = precioAudioguias - descuentoguias;


    public int getentradasAdultos() {
        return entradasAdultos;
    }
    public int getentradasNinhos() {
        return entradasNinhos;
    }
    public int getentradasAudioguias() {
        return audioguias;
    }
    
    public Ticket(int entradasAdultos, int entradasNinhos, int audioguias, String cliente) {
        this.entradasAdultos = entradasAdultos;
        this.entradasNinhos = entradasNinhos;
        this.audioguias = audioguias;
        this.cliente = cliente;
    }

    public double calcularSubtotal() {
        double subtotal = (precioAdultos * entradasAdultos) + (precioNinhos * entradasNinhos) + (precioAudioguias * audioguias);
        return subtotal;
    }

    public double calcularDescuentoAudioguias() {
        double ahorro = precioAudioguias - audioguiasConDescuento;
        return ahorro;
    }
    public double calcularTotal() {
        double totalConDescuento = calcularSubtotal() - calcularDescuentoAudioguias();
        return totalConDescuento;
    }
    public void imprimirTicket() {
        System.out.println();
        System.out.println("=========================================");
        System.out.printf("%25s\n", "Cueva de Nerja");
        System.out.println("=========================================");

        System.out.printf("Cliente: %s\n", cliente);
        System.out.println();
        System.out.printf("%-20s %-10s Importe\n", "producto", "cantidad");
        System.out.println("-----------------------------------------");
        System.out.printf("%-20s %-10d %,.02f €\n", "adultos", entradasAdultos, precioAdultos );
        System.out.printf("%-20s %-11d %,.02f €\n", "ninhos", entradasNinhos, precioNinhos );
        System.out.printf("%-20s %-10d %,.02f €\n", "guias", audioguias, precioAudioguias );
        System.out.println("-----------------------------------------");
        System.out.println();
        System.out.printf("%-31s %,.02f €\n", "subtotal", calcularSubtotal());

        System.out.printf("%-32s %,.02f €\n", "descuento", descuentoguias);

        System.out.printf("\033[01m\033[47m\033[31m%-36S %,.02f €\033[00m\n", "\033[47mTotal a pagar:", calcularTotal());
        System.out.println("=========================================");
    }

    



}