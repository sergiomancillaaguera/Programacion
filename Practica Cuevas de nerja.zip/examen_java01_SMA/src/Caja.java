public class Caja {
    private static int adultosAcumulados;
    private static int ninhosAcumulados;
    private static int audioguiasAcumuladas;
    private static int ingresosAcumulados;
    private static int descuentosAcumulados;

    public void registrarTicket(Ticket ticket) {
        adultosAcumulados += ticket.getentradasAdultos();
        ninhosAcumulados += ticket.getentradasNinhos();
        audioguiasAcumuladas += ticket.getentradasAudioguias();
        ingresosAcumulados += ticket.calcularTotal();
        descuentosAcumulados += ticket.calcularDescuentoAudioguias();
    }

    public void mostrarResumenDia() {
        System.out.println("=========================================");
        System.out.printf("%25s\n", "Desglose diario");
        System.out.println("=========================================");
        System.out.println("Entradas de adultos: " + adultosAcumulados);
        System.out.println("Entradas de niños: " + ninhosAcumulados);
        System.out.println("Packs de Audioguias: " + audioguiasAcumuladas);
        System.out.println("=========================================");
        System.out.println("Total ahorrado por los clientes: " + descuentosAcumulados);
        System.out.println("=========================================");
        System.out.println("Recaudación total: " + ingresosAcumulados);
        System.out.println("=========================================");
    }
}
